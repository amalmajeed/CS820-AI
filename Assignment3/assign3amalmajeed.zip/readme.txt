

Incase the random generator cannot generate a consistent problem, try the below parameters :

n = 4
p = 0.11
r = 0.2
alpha = 0.9

np ( max no of parents ) : 2

k ( no of pareto solutions ) : any number less than domain size generated after the above parameters are input