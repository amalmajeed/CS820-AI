Assignment 1 : Prolog Unification
Submitted By : First Name : Amal Majeed 
				Last Name : Mucheth Abdul Majeed
				Student Number : 200415928



Program	Constraint : All variables, functions and constants are single characters and not strings.
						Any string(more than one alphabets together) will be treated as Invalid in this 
						program.

						Variables are Uppercase , function names and constants are Lower case




Instruction to run : 'python assign1amalmajeed.py'

		Example inputs : Expr 1 : f(x,Y)    - function with x - constant and Y - variable
						 Expr 2 : f(A,g(A)) - function with A - variable and g(A) - function 

						 Unified expression : f(x,g(x))

		Screenshots of same example and a failure case example have been attached with the zip file


All functions in the program have a comment describing them. Program is compatible with python2.4 compiler and all other 2.x compilers of python.

Program ran without issues on hercules machine.