 ASSIGNMENT 2 

 SUBMITTED BY :- AMAL MAJEED MUCHETH ABDUL MAJEED
 				 200415928


Please read the following key facts about the program.



1) The program will initially ask if you want to randomly generate a problem or choose to run the algorithms on a previously observed example which was consistent as a yes/no . I did this because the python 'random' module kept throwing constraints/problems such that majority of random problem parameters/constraints generated were inconsistent/unsolvable and hence took a lot of time to test the 3  algorithms on a randomly generated problem that was consistent , so i hardcoded one of the observations that i got after many tries for the marker if not able to generate a consistent problem with random option after lot of tries

2) If trying to randomly generate the problem , the values of parameters where i had the highest possibility of generating a solvable problem was p = 0.11 , r = 0.2 , alpha = 0.9

3) I have given two images with the same parameters in the cases I tested where two different set of constraints were generated as a proof that problems are randomly generated in each try.